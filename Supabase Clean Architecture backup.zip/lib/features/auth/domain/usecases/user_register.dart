import 'package:fpdart/fpdart.dart';
import 'package:nextrep/core/error/failures.dart';
import 'package:nextrep/core/usecase/usecase.dart';
import 'package:nextrep/core/common/entities/user.dart';
import 'package:nextrep/features/auth/domain/repository/auth_repository.dart';

class UserRegister implements UseCase<User, UserRegisterParams> {
  final AuthRepository authRepository;
  const UserRegister(this.authRepository);
  @override
  Future<Either<Failure, User>> call(UserRegisterParams params) async {
    return await authRepository.registerWithEmailPassword(
      name: params.name,
      email: params.email,
      password: params.password,
    );
  }
}

class UserRegisterParams {
  final String name;
  final String email;
  final String password;
  UserRegisterParams({
    required this.name,
    required this.email,
    required this.password,
  });
}
