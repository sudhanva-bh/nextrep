import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nextrep/core/constants/file_paths.dart';
import 'package:nextrep/core/navigation/navigate_with_push.dart';
import 'package:nextrep/core/theme/app_palette.dart';
import 'package:nextrep/core/utils/show_snackbar.dart';
import 'package:nextrep/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:nextrep/features/auth/presentation/pages/login_section.dart';
import 'package:nextrep/features/auth/presentation/pages/register_section.dart';
import 'package:nextrep/features/loader.dart';
import 'package:nextrep/features/metrics/presentation/pages/gender_collection.dart';

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final formKey = GlobalKey<FormState>();

  late Widget currentSection;
  late Widget switchToNextSection;

  late bool isNewUser = true;

  late Map<String, TextEditingController> controllers;

  void goToLogin() {
    setState(() {
      currentSection = LoginSection(
        loginWithEmailPassword: loginWithEmailPassword,
        continueWithGoogle: continueWithGoogle,
        continueWithApple: continueWithApple,
        controllers: controllers,
        switchSections: goToRegister,
      );
      switchToNextSection = GestureDetector(
        onTap: goToRegister,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("New Here? "),
              Text(
                "Register",
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
            ],
          ),
        ),
      );
      isNewUser = false;
    });
  }

  void goToRegister() {
    setState(() {
      currentSection = RegisterSection(
        registerWithEmailPassword: registerWithEmailPassword,
        continueWithGoogle: continueWithGoogle,
        continueWithApple: continueWithApple,
        controllers: controllers,
        switchSections: goToLogin,
      );
      switchToNextSection = GestureDetector(
        onTap: goToLogin,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("Already a Member? "),
              Text(
                "Login",
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
            ],
          ),
        ),
      );
      isNewUser = true;
    });
  }

  void registerWithEmailPassword() {
    if (formKey.currentState!.validate()) {
      context.read<AuthBloc>().add(
        AuthRegister(
          email: controllers['email']!.text.trim(),
          password: controllers['password']!.text.trim(),
          name: controllers['name']!.text.trim(),
        ),
      );
    }
  }

  void loginWithEmailPassword() {
    if (formKey.currentState!.validate()) {
      context.read<AuthBloc>().add(
        AuthLogin(
          email: controllers['email']!.text.trim(),
          password: controllers['password']!.text.trim(),
        ),
      );
    }
  }

  void continueWithGoogle() {}

  void continueWithApple() {}

  @override
  void initState() {
    super.initState();
    controllers = {
      'name': TextEditingController(),
      'email': TextEditingController(),
      'password': TextEditingController(),
      'confirmPassword': TextEditingController(),
    };
    goToRegister();
  }

  @override
  void dispose() {
    for (final controller in controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: BlocConsumer<AuthBloc, AuthState>(
                listener: (context, state) {
                  if (state is AuthFailure) {
                    showSnackBar(context, state.message);
                  }
                },
                builder: (context, state) {
                  if (state is AuthLoading) {
                    return const Loader();
                  } else if (state is AuthSuccess) {
                    NavigateWithPush(
                      context,
                      isNewUser ? GenderCollection() : Placeholder(),
                    );
                  }
                  return Form(
                    key: formKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Center(
                          child: Image.asset(
                            FilePaths.mainLogo,
                            height: 200,
                          ),
                        ),
                        const SizedBox(
                          height: 25,
                        ),
                        AnimatedSize(
                          duration: const Duration(milliseconds: 400),
                          curve: Curves.easeInOut,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              vertical: 26,
                              horizontal: 16,
                            ),
                            decoration: BoxDecoration(
                              color: AppPalette.surface,
                              borderRadius: BorderRadius.circular(32),
                            ),
                            child: currentSection,
                          ),
                        ),
                        const SizedBox(
                          height: 12,
                        ),
                        switchToNextSection,
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}
