import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nextrep/core/common/cubits/app_user/app_user_cubit.dart';
import 'package:nextrep/core/secrets/app_secrets.dart';
import 'package:nextrep/core/theme/theme.dart';
import 'package:nextrep/features/auth/data/datasources/auth_remote_data_source.dart';
import 'package:nextrep/features/auth/data/repositories/auth_repository_impl.dart';
import 'package:nextrep/features/auth/domain/usecases/current_user.dart';
import 'package:nextrep/features/auth/domain/usecases/user_login.dart';
import 'package:nextrep/features/auth/domain/usecases/user_register.dart';
import 'package:nextrep/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:nextrep/features/home/presentation/pages/home_page.dart';
import 'package:nextrep/features/welcome/presentation/pages/welcome_page.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  final supabase = await Supabase.initialize(
    url: AppSecrets.supabaseUrl,
    anonKey: AppSecrets.anonKey,
  );
  final appUserCubit = AppUserCubit();
  runApp(
    MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => appUserCubit),
        BlocProvider(
          create: (_) => AuthBloc(
            userRegister: UserRegister(
              AuthRepositoryImpl(AuthRemoteDataSourceImpl(supabase.client)),
            ),
            userLogin: UserLogin(
              AuthRepositoryImpl(AuthRemoteDataSourceImpl(supabase.client)),
            ),
            currentUser: CurrentUser(
              AuthRepositoryImpl(AuthRemoteDataSourceImpl(supabase.client)),
            ),
            appUserCubit: AppUserCubit(),
          ),
        ),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();
    context.read<AuthBloc>().add(AuthIsUserLoggedIn());
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "NextRep",
      theme: AppTheme.darkTheme,

      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(
            context,
          ).copyWith(textScaler: TextScaler.linear(1.0)),
          child: child!,
        );
      },

      home: BlocSelector<AppUserCubit, AppUserState, bool>(
        selector: (state) {
          return state is AppUserLoggedIn;
        },
        builder: (context, isLoggedIn) {
          if (isLoggedIn) {
            return HomePage();
          }
          return const WelcomePage();
        },
      ),
    );
  }
}
