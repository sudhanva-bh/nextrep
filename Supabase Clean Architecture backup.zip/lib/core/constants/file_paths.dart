class FilePaths {
  static const mainLogo = "assets/core/logo.png";

  static const welcomeImage = "assets/welcome_screen/WelcomeScreen.jpg";

  static const googleLogo = "assets/sign_in/google_logo.webp";
  static const appleLogo = "assets/sign_in/apple_logo.png";

  static const maleLottie = "assets/lottie/genders/male.json";
  static const femaleLottie = "assets/lottie/genders/female.json";
  static const nonBinaryLottie = "assets/lottie/genders/non_binary.json";

  static const beginnerExperience = "assets/experience/beginner.png";
  static const intermediateExperience = "assets/experience/intermediate.png";
  static const advancedExperience = "assets/experience/advanced.png";
}
