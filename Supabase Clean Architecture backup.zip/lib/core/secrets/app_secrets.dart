class AppSecrets {
  static const supabaseUrl = "https://grnemxsxrlolzearbggz.supabase.co";
  static const anonKey =
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdybmVteHN4cmxvbHplYXJiZ2d6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIxNTkyODYsImV4cCI6MjA2NzczNTI4Nn0.fgBKwuK2U4AhdmXnbip6g8kqnES-6doO1AtmQg2p8IE";
}
